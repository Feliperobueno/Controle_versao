package revendedora;

import java.util.Scanner;
import modelos.Comida;
import modelos.Vendedor;
import modelos.Cliente;

public class Restaurante {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

      //enviando parametros via construtor
        Vendedor vendedor1 = new Vendedor("101", "Alberto");
        Vendedor vendedor2 = new Vendedor("102", "João", 2000.00);
                
        System.out.println("Digite seu Nome: ");
        String nome_cliente = entrada.nextLine();
        
        System.out.println("Insira seu CPF: ");
        String cpf_cliente = entrada.nextLine();
        
        System.out.println("Insira seu telefone: ");
        String telefone_cliente = entrada.nextLine();
        
        System.out.println("Insira seu endereço: ");
        String endereco_cliente = entrada.nextLine();
        
        Cliente cliente1 = new Cliente(nome_cliente, cpf_cliente, telefone_cliente, endereco_cliente);       
        
        //enviando parametros via construtor
        Comida cochinha = new Comida();
        cochinha.nome = "Cochinha";
        cochinha.codigo = 1;
        cochinha.tamanho = "Grande";
        cochinha.tipo = "Salgado";
        cochinha.preco = 4;

        Comida cupcake = new Comida();
        cupcake.nome = "CupCake";
        cupcake.codigo = 3;
        cupcake.tamanho = "Medio";
        cupcake.tipo = "Doce";
        cupcake.preco = 2;

        Comida sushi = new Comida();
        sushi.nome = "Sushi";
        sushi.codigo = 4;
        sushi.tamanho = "Pequeno";
        sushi.tipo = "Salgado";
        sushi.preco = 20.00;

        Comida taco = new Comida();
        taco.nome = "Taco";
        taco.codigo = 5;
        taco.tamanho = "Grande";
        taco.tipo = "Salgado";
        taco.preco = 8;

        Comida americano = new Comida();
        americano.nome = "Americano";
        americano.codigo = 2;
        americano.tamanho = "Medio";
        americano.tipo = "Salgado";
        americano.preco = 4;


        System.out.println("-------------------------------------------Vendedores Disponíveis------------------------------------------------");
        System.out.println("Nome vendedor 1: " + vendedor1.nome);
        System.out.println("Nome vendedor 2: " + vendedor2.nome);
        System.out.println("-----------------------------------------------------------------------------------------------------------------");

        System.out.print("Insira o codigo do vendedor:");
        
        String codigo_vendedor_escolhido = entrada.nextLine();
        
        System.out.print("Insira o codigo da comida:");
         
        String codigo_comida_escolhida = entrada.nextLine();

        Comida comida_escolhida = new Comida();
        Vendedor vendedor_escolhido = new Vendedor();
        
        if (vendedor1.matricula.equals(codigo_vendedor_escolhido)) {
            vendedor_escolhido = vendedor1;

        } 
       
        else if (vendedor2.matricula.equals(codigo_vendedor_escolhido)) {
            vendedor_escolhido = vendedor2;

        }

        if (cochinha.codigo == Integer.parseInt(codigo_comida_escolhida)) {
            comida_escolhida = cochinha;
            System.out.println("Nome: " + cochinha.nome);
            System.out.println("Codigo: " + cochinha.codigo);
            System.out.println("Tipo da comida: " + cochinha.tipo);
            System.out.println("Tamanho da comida: " + cochinha.tamanho);
            System.out.println("Preço: " + cochinha.preco);
            System.out.println("-----------------------------------------------------------------------------------------------------");
        } 
        
        else if (americano.codigo == Integer.parseInt(codigo_comida_escolhida)) {
            comida_escolhida = americano;
            System.out.println("Nome: " + americano.nome);
            System.out.println("Codigo: " + americano.codigo);
            System.out.println("Tipo da comida: " + americano.tipo);
            System.out.println("Tamanho da comida: " + americano.tamanho);
            System.out.println("Preço: " + americano.preco);
            System.out.println("-----------------------------------------------------------------------------------------------------");
        } 
        
        else if (cupcake.codigo == Integer.parseInt(codigo_comida_escolhida)) {
            comida_escolhida = cupcake;
            System.out.println("Nome: " + cupcake.nome);
            System.out.println("Codigo: " + cupcake.codigo);
            System.out.println("Tipo da comida: " + cupcake.tipo);
            System.out.println("Tamanho da comida: " + cupcake.tamanho);
            System.out.println("Preço: " + cupcake.preco);
            System.out.println("-----------------------------------------------------------------------------------------------------");
        } 
       
        else if (taco.codigo == Integer.parseInt(codigo_comida_escolhida)) {
            comida_escolhida = taco;
            System.out.println("Nome: " + taco.nome);
            System.out.println("Codigo: " + taco.codigo);
            System.out.println("Tipo da comida: " + taco.tipo);
            System.out.println("Tamanho da comida: " + taco.tamanho);
            System.out.println("Preço: " + taco.preco);
            System.out.println("-----------------------------------------------------------------------------------------------------");
        } 
       
        else if (sushi.codigo == Integer.parseInt(codigo_comida_escolhida)) {
            comida_escolhida = sushi;
            System.out.println("Nome: " + sushi.nome);
            System.out.println("Codigo: " + sushi.codigo);
            System.out.println("Tipo da comida: " + sushi.tipo);
            System.out.println("Tamanho da comida: " + sushi.tamanho);
            System.out.println("Preço: " + sushi.preco);
            System.out.println("-----------------------------------------------------------------------------------------------------");
        }
        


//Enviando mensagem atraves do objeto da classe Cliente
        //Enviando mensagem atraves do objeto da classe Vendedor
        vendedor1.vender(01, 2, cliente1, vendedor_escolhido, comida_escolhida);

    }

}
