package modelos;

public class Venda {

    int codigo;
    int tipo;
    Cliente cliente;
    Vendedor vendedor;
    Comida comida;
    

    public Venda(int codigo, int tipo, Cliente cliente, Vendedor vendedor, Comida comida) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.comida = comida;
    }

    
    }


