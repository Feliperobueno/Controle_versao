package modelos;

public class Cliente {

    int codigo;
    String nome;
    String cpf;
    String telefone;
    String endereco;

    public Cliente(String nome, String cpf, String telefone, String endereco) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.endereco = endereco;
    }

    public void comprar(Comida comida) {
        System.out.println("Iniciando pedido de venda..............");
        System.out.println("O cliente  " + this.nome + "  quer comprar o " + Comida.tipo + ".");
        System.out.println("-----------------------------------------------------------");
    }

   
    }


