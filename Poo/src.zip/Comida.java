package modelos;

public class Comida {
    
    public int codigo;
    public  String nome;
    public static String tipo;
    public String tamanho;
    public double preco;

    public Comida() {
    }

    public Comida(int codigo, String nome, String tamanho, String tipo, double preco) {
        this.nome = nome;
        this.tipo = tipo;
        this.tamanho = tamanho;
        this.preco = preco;
    }

    

}
